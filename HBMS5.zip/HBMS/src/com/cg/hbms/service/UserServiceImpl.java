package com.cg.hbms.service;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;

import com.cg.hbms.dao.MyStringDateUtil;
import com.cg.hbms.dao.UserDao;
import com.cg.hbms.dao.UserDaoImpl;
import com.cg.hbms.dto.BookingDetails;
import com.cg.hbms.dto.Hotel;
import com.cg.hbms.dto.Users;
import com.cg.hbms.dto.roomDetails;
import com.cg.hbms.exception.HotelException;

public class UserServiceImpl implements UserService{

	UserDao userDao;
	public UserServiceImpl() throws HotelException
	{
		userDao = new UserDaoImpl();
	}
	@Override
	public int bookRoom(BookingDetails bookingDetails) throws HotelException {
		// TODO Auto-generated method stub
		return userDao.bookRoom(bookingDetails);
	}
	@Override
	public ArrayList<BookingDetails> viewBookingStatus(String userId) throws HotelException {
		// TODO Auto-generated method stub
		return userDao.viewBookingStatus(userId);
	}
	@Override
	public int addUser(Users user) throws HotelException {
		// TODO Auto-generated method stub
		return userDao.addUser(user);
	}
	@Override
	public String login(String userId, String password) throws HotelException{
		// TODO Auto-generated method stub
		
		return userDao.login(userId, password);
	}
	@Override
	public ArrayList<roomDetails> searchRoom(String hotel_id) throws HotelException{
		// TODO Auto-generated method stub
		return userDao.searchRoom(hotel_id);
	}
	@Override
	public boolean validate_userName(String username) throws HotelException {
		// TODO Auto-generated method stub
		ArrayList<String> userNames = userDao.getListofUsername();
		if(username.length()>4)
		{
			System.out.println("length exceeded");
			return false;
		}
			
		if(userNames.contains(username))
			return false;
		
		return true;
	}
	@Override
	public boolean validate_password(String password) throws HotelException {
		// TODO Auto-generated method stub
		String pattern = "((?=.*[a-z])(?=.*\\d)(?=.*[A-Z])(?=.*[@#$%!]).{8,20})";
		if(password.matches(pattern))
			return true;
		return false;
	}
	@Override
	public boolean validate_name(String name) throws HotelException {
		// TODO Auto-generated method stub
		String pattern = "[A-Z][a-z]{1,20}";
		if(name.matches(pattern))
			return true;
		return false;
	}
	@Override
	public ArrayList<Hotel> getHotelsByName(String hotelName) throws HotelException {
		// TODO Auto-generated method stub
		return userDao.getHotelsByName(hotelName);
	}

	@Override
	public ArrayList<Hotel> getHotelsByCity(String city) throws HotelException {
		// TODO Auto-generated method stub
		return userDao.getHotelsByCity(city);
	}
	@Override
	public ArrayList<Hotel> getHotelIdByHotelNameAndCityName(String hotelName,String cityName) throws HotelException {
		// TODO Auto-generated method stub
		return userDao.getHotelIdByHotelNameAndCityName(hotelName,cityName);
	}
	@Override
	public int changeAvailabilityStatus(String status, String room_id, String hotel_id) throws HotelException {
		// TODO Auto-generated method stub
		return userDao.changeAvailabilityStatus(status, room_id, hotel_id);
	}
	@Override
	public boolean validateDate(String dateToValidate, String dateFromat) throws HotelException {
		if(dateToValidate == null){
			return false;
		}
		LocalDate date1 = MyStringDateUtil.fromStringToLocalDate(dateToValidate);
		LocalDate today = LocalDate.now();
		SimpleDateFormat sdf = new SimpleDateFormat(dateFromat);
		sdf.setLenient(false);
		
		try {
			
			//if not valid, it will throw ParseException
			Date date = sdf.parse(dateToValidate);
	
		
		} catch (ParseException e) {
			
			throw new HotelException(e.getMessage());
		}
		if(date1.compareTo(today)>=0)
		{
			
			return true;
		}
		
		return false;
		
	}
	@Override
	public boolean validateCheckOutDate(String dateToValidate, LocalDate checkIn, String dateFormat) throws HotelException {
		// TODO Auto-generated method stub
		if(dateToValidate == null){
			return false;
		}
		LocalDate date1 = MyStringDateUtil.fromStringToLocalDate(dateToValidate);
		LocalDate today = LocalDate.now();
		SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
		sdf.setLenient(false);
		
		try {
			
			//if not valid, it will throw ParseException
			Date date = sdf.parse(dateToValidate);
	
		
		} catch (ParseException e) {
			throw new HotelException(e.getMessage());
		}
		if(date1.compareTo(checkIn)>0)
		{
			
			return true;
		}
		return false;
	}

}
