package com.cg.hbms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.hbms.dto.BookingDetails;
import com.cg.hbms.dto.Hotel;
import com.cg.hbms.dto.Users;
import com.cg.hbms.dto.roomDetails;
import com.cg.hbms.exception.HotelException;
import com.cg.hbms.util.DBUtil;

public class UserDaoImpl implements UserDao {
	Connection con;
	public UserDaoImpl() throws HotelException
	{
		con = DBUtil.getcon();

	}
	@Override
	public String login(String userId, String password) throws HotelException {
		// TODO Auto-generated method stub
		String role="";
		try	{
		String qry="Select role from Users where user_Id=? and password=?";
		
		try {
			PreparedStatement pstmt = con.prepareStatement(qry);
			pstmt.setString(1, userId);
			pstmt.setString(2, password);
			ResultSet rs = pstmt.executeQuery();
			
			if (rs.next()) {
				
				role =rs.getString(1);
				}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		}
		catch(Exception e)	{
			throw new HotelException(e.getMessage());
		}
		return role;
}

	@Override
	public ArrayList<roomDetails> searchRoom(String hotel_id) {
		// TODO Auto-generated method stub
		String qry="Select * from roomdetails where hotel_id=? and availability = 'Y'";
		ArrayList<roomDetails> list = new ArrayList<roomDetails>();
		try {
			PreparedStatement pstmt = con.prepareStatement(qry);
			pstmt.setString(1, hotel_id);
			
			roomDetails room=null;
			ResultSet rs = pstmt.executeQuery();
			
			while (rs.next()) {
				room =new roomDetails(rs.getString("hotel_id"),rs.getString("room_id"),rs.getString("room_no"), rs.getString("room_type"),rs.getDouble("per_night_rate"), rs.getString("availability").charAt(0));
				list.add(room);
				}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public int bookRoom(BookingDetails bookingDetails) throws HotelException {
		
		String qry = "INSERT INTO BookingDetails VALUES(booking_id_seq.nextval,?,?,?,?,?,?,?,?)";
		PreparedStatement pst;
		int bookRoom=0;
		try {
			pst = con.prepareStatement(qry);
			pst.setString(8, bookingDetails.getHotel_id());
			pst.setString(1,bookingDetails.getRoom_id());
			pst.setString(2,bookingDetails.getUser_id());
			pst.setDate(3, Date.valueOf(bookingDetails.getBooked_from()));
			pst.setDate(4, Date.valueOf(bookingDetails.getBooked_to()));
			pst.setInt(5,bookingDetails.getNo_of_adults());
			pst.setInt(6, bookingDetails.getNo_of_children());
			pst.setDouble(7, bookingDetails.getAmount());
			 bookRoom = pst.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return bookRoom;

	}
	@Override
	public ArrayList<BookingDetails> viewBookingStatus(String userId) throws HotelException  {
	
		String qry = "SELECT * from BookingDetails where user_id=? and booked_to <= sysdate";
		ArrayList<BookingDetails> list = new ArrayList<BookingDetails>();
		PreparedStatement pst1;
		try {
			pst1 = con.prepareStatement(qry);
			pst1.setString(1, userId);
			ResultSet rs = pst1.executeQuery();
			

			while (rs.next()) {
				LocalDate bookedFrom = rs.getDate(4).toLocalDate();
				LocalDate bookedTo = rs.getDate(5).toLocalDate();
				list.add(new BookingDetails(rs.getString(1),rs.getString(9),rs.getString(2),rs.getString(3),bookedFrom,bookedTo,rs.getInt(6),rs.getInt(7),rs.getDouble(8)));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new HotelException(e.getMessage());
		}
		
		return list;
		
	}
	@Override
	public int addUser(Users user) throws HotelException {
		
		String qry = "INSERT INTO Users values(?,?,?,?,?,?,?,?)";
		PreparedStatement pst;
		int insUser=0;
		try {
			pst = con.prepareStatement(qry);
			System.out.println(user.getPassword());
			System.out.println(user.getUser_id());
			pst.setString(1, user.getUser_id());
			pst.setString(2, user.getPassword());
			pst.setString(3, user.getRole());
			pst.setString(4, user.getUser_name());
			pst.setString(5, user.getMobile_phone());
			pst.setString(6, user.getPhone());
			pst.setString(7, user.getAddress());
			pst.setString(8, user.getEmail());
			insUser = pst.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new HotelException(e.getMessage());
		}
		
		
		
		return insUser;
	}
	@Override
	public ArrayList<String> getListofUsername() throws HotelException	{
		// TODO Auto-generated method stub
		ArrayList<String> userNameList = new ArrayList<String>();
		String qry = "Select user_id from users ";
		Statement stmt;
		try {
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			while(rs.next())
			{
				userNameList.add(rs.getString(1));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new HotelException(e.getMessage());
		}
		
		return userNameList;
	}
	
	@Override
	public ArrayList<Hotel> getHotelIdByHotelNameAndCityName(String hotelName, String cityName) throws HotelException {
		// TODO Auto-generated method stub
		String qry = "select * from hotel where hotel_name= ? and city = ?";
		ArrayList<Hotel> list = new ArrayList<Hotel>();
		try {
			PreparedStatement pst = con.prepareStatement(qry);
			pst.setString(1, hotelName);
			pst.setString(2, cityName);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				Hotel hotel = new Hotel(rs.getString("hotel_id"), rs.getString("city"), rs.getString("hotel_name"),
						rs.getString("address"), rs.getString("description"), rs.getInt("avg_rate_per_night"),
						rs.getString("phone_no1"), rs.getString("phone_no2"), rs.getString("rating"),
						rs.getString("email"), rs.getString("fax"));
				list.add(hotel);
			}
		} catch (Exception e) {
			throw new HotelException(e.getMessage());
		}
		return list;
			
	}
	@Override
	public int changeAvailabilityStatus(String status,String room_id,String hotel_id) throws HotelException {
		// TODO Auto-generated method stub
		int updatedStatus=0;
		PreparedStatement pst;
		try {
		if(status=="Y" || status=="y")
		{
			String qry = "update roomdetails set availability = 'Y' where room_id = ? and hotel_id = ?";
			
			pst = con.prepareStatement(qry);
			pst.setString(1, room_id);
			pst.setString(2, hotel_id);
			updatedStatus = pst.executeUpdate();
		}
		else
		{
			String qry = "update roomdetails set availability = 'N' where room_id = ? and hotel_id = ?";
			pst = con.prepareStatement(qry);
			pst.setString(1, room_id);
			pst.setString(2, hotel_id);
			updatedStatus = pst.executeUpdate();
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new HotelException(e.getMessage());
		}
		return updatedStatus;
	}
	@Override
	public ArrayList<Hotel> getHotelsByName(String hotelName) throws HotelException {
		// TODO Auto-generated method stub
		String qry="Select hotel_id,address,phone_no1,phone_no2,rating,email from Hotel where hotel_name=?";
		ArrayList<Hotel> list=new ArrayList<Hotel>();
		Hotel h=null;
		try
		{
			PreparedStatement pst=con.prepareStatement(qry);
			pst.setString(1, hotelName);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				h=new Hotel(rs.getString("hotel_id"),rs.getString("address"),rs.getString("phone_no1"),rs.getString("phone_no2"),rs.getString("rating"),rs.getString("email"));
				list.add(h);
			}
		
	
			
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(list.size()==0)
			throw new HotelException();
		return list;
	}
		
		
	

	@Override
	public ArrayList<Hotel> getHotelsByCity(String city) throws HotelException {
		// TODO Auto-generated method stub
		String qry="Select hotel_id,hotel_name,address,phone_no1 from Hotel where city=?";
		ArrayList<Hotel> list=new ArrayList<Hotel>();
		Hotel h=null;
		try
		{
			PreparedStatement pst=con.prepareStatement(qry);
			pst.setString(1, city);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				h=new Hotel(rs.getString("hotel_id"),rs.getString("hotel_name"),rs.getString("address"),rs.getString("phone_no1"));
				list.add(h);
			}
		
	
			
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(list.size()==0)
			throw new HotelException();
		return list;
	}
}
