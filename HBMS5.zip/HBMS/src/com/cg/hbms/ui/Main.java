package com.cg.hbms.ui;


import java.util.Scanner;
import com.cg.hbms.exception.HotelException;
import com.cg.hbms.service.AdminService;
import com.cg.hbms.service.AdminServiceImpl;
import com.cg.hbms.service.UserService;
import com.cg.hbms.service.UserServiceImpl;

public class Main {
	static UserService userService = null;
	static AdminService admService = null;
	static Scanner sc = new Scanner(System.in);
	static boolean login = false;
	static int choice;
	public static void main(String[] args) {
		try {
			userService = new UserServiceImpl();
		} catch (HotelException e) {
			System.out.println(e.getMessage());
		}
	
				System.out.println("--------------------------------------------------------------------------------------------------------------------");
				System.out.println("*****************************Welcome to Hotel Booking Management System*********************************************");
				System.out.println("--------------------------------------------------------------------------------------------------------------------");
				
				
				System.out.println("1.Login");
				System.out.println("2.Register");
				System.out.println("3.Exit");
				int choice=0;
				choice = Integer.parseInt(sc.nextLine());
				switch(choice)
				{
				case 1:
					login();
					break;
				case 2:
					@SuppressWarnings("unused") 
					User use = new User();
					User.register();
					break;
				case 3:
					System.exit(0);
				default :
					System.out.println("Wrong Choice");
				}
		
				
				
		}
	
	private static void login()
	{
		while (login == false) {
			try {
				
				System.out.println("Enter your userId:");
				String userId = sc.nextLine();
				System.out.println("Enter your password:");
				String password = sc.nextLine();
				String role = "";
				role = userService.login(userId, password);
				if (role.equals("")) {
					throw new HotelException("Please Enter UserName and Password Again");
				}
				
				if (role.equals("admin")) {
					adminLogin();
				} else if (role.equals("user")) {
					userLogin(userId);
				}
				else	{
					throw new HotelException("Role Configured wrong by Admin. Please Contact Admin for update");
				}
			} catch (HotelException e) {
				System.out.println(e.getMessage());
				continue;
			}
		}
	}
	public static void userLogin(String userId)	{
		@SuppressWarnings("unused")
		User use = new User();
		login = true;
		System.out.println("----------------------------------------------------------------------------------------------------------");
		System.out.println("Welcome User");
		try	{
		while (login) {
			System.out.println("---------Options Available----------------");
			System.out.println("1.Search Hotel" + "\n" + "2. Book Room" + "\n" + "3.Check Status of Booking"+"\n"+"3.Logout");
			choice = Integer.parseInt(sc.nextLine());
			switch (choice) {
			case 1:
				User.search();
				break;
			case 2:
				User.bookRoom(userId);
				break;
			case 3:
				User.checkStatus(userId);
				break;
			case 4:
				login = false;
				try {
					final String os = System.getProperty("os.name");
					if (os.contains("Windows")) {
						Runtime.getRuntime().exec("cls");
					} else {
						Runtime.getRuntime().exec("clear");
					}
					break;
				} catch (Exception e) {
					throw new HotelException(e.getMessage());
				}
			default:
				System.out.println("Invalid Choice");
				break;
			}
		}
		}
		catch (HotelException e) {
			System.out.println(e.getMessage());
		}
	}
	public static void adminLogin()	{
		@SuppressWarnings("unused")
		Admin admin = new Admin();
		login = true;
		try {
			admService = new AdminServiceImpl();
			while (login) {
				System.out.println("--------------------------------------------------------------------------------------------------------------------");
				System.out.println("Welcome Admin");
				System.out.println("Options Available:-");
				System.out.println("1. Add Hotel");
				System.out.println("2. Delete Hotel");
				System.out.println("3. Update Hotel");
				System.out.println("4. View All Hotels");
				System.out.println("5. View All Bookings By Hotel");
				System.out.println("6. View Bookings for a Date");
				System.out.println("7. Add Room for a hotel");
				System.out.println("8. Delete Room of a Hotel");
				System.out.println("9. Update Room Details");
				System.out.println("10. Add a new Admin");
				System.out.println("11. Logout");
				choice = Integer.parseInt(sc.nextLine());
				switch (choice) {
				case 1:
					Admin.addHotel();
					break;
				case 2:
					Admin.deleteHotel();
					break;
				case 3:
					Admin.update();
					break;
				case 4:
					Admin.fetchAll();
					break;
				case 5:
					Admin.fetchAllBookings();
					break;
				case 6:
					Admin.viewBookingByDate();
					break;
				case 7:
					Admin.addRoom();
					break;
				case 8:
					Admin.delRoom();
					break;
				case 9:
					Admin.updateRoomDetails();
					break;
				case 10:
					Admin.addAdmin();
					break;
				case 11:
					login = false;
					break;
				default:
					System.out.println("Invalid Choice");					
					break;
				}
			}
		}
		catch(HotelException e) {
			System.out.println(e.getMessage());
			System.out.println("--------------------------------------------------------------------------------------------------------------------");
		}
	}
	
}